from django.shortcuts import render,redirect

# Create your views here.
import requests
import json
import geocoder
from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse_lazy
from django.views import generic


class SignUp(generic.CreateView):
    form_class = UserCreationForm
    success_url = reverse_lazy('login')
    template_name = 'signup.html'
def report(request):
    return render(request,'report.html')
def page(request):
    return render(request,'page.html')
#def done(request):
 #   return render(request,'done.html')


URL = 'https://www.sms4india.com/api/v1/sendCampaign'

# get request
def sendPostRequest(reqUrl, apiKey, secretKey, useType, phoneNo, senderId, textMessage):
  req_params = {
  'apikey':apiKey,
  'secret':secretKey,
  'usetype':useType,
  'phone': phoneNo,
  'message':textMessage,
  'senderid':senderId
  }
  return requests.post(reqUrl, req_params)

def done(request):
  res = requests.get('https://ipinfo.io/')
  data = res.json()
  city = data['city']
  location = data['loc'].split(',')
  latitude = str(location[0])
  longitude = str(location[1])
  print("Latitude : "+latitude)
  print("Longitude : "+longitude)
  print("City : "+city)
  print(locatio)
  #response = sendPostRequest(URL,'7K3EOGYORRCTZA1OAC7XY9X61L9QVWE3', '76CSKW9A5SW1PJ6W', 'stage','9515780648', 'pshivramiit@gmail.com',"Latitude : "+latitude+"Longitude : "+longitude+"City : "+city)
  #print(response.text)
  g = geocoder.ip('157.48.44.11')
  print(g)
  #http://api.ipapi.com/157.48.44.11?access_key=113964de8d00de1f0da6bfe6eb893d16
  print(g.geojson)
  print(g.ip)
  return render(request,'done.html')

