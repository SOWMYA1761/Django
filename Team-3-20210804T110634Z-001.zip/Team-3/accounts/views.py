global msg,alp,num,alph
from django.shortcuts import render,redirect
from django.contrib import messages
from django.contrib.auth.models import User,auth
from .models import tranferr
import smtplib
import math,random
import psycopg2
alp=['@','#','$','%','&','+','-','_']
num=['0','1','2','3','4','5','6','7','8','9']
alph=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
def generateOTP():
    digits="0123456789"
    OTP=""
    for i in range(4):
        OTP+=digits[int(math.floor(random.random()*10))]
    return OTP
import smtplib
#fromaddr="18wh1a0419@bvrithyderabad.edu.in"
#toaddr="18wh1a0552@bvrithyderabad.edu.in"
msg=generateOTP()
print(msg)
#password="sowmya1761"
#server=smtplib.SMTP('smtp.gmail.com:587')
#server.starttls()
#server.login(fromaddr,password)
#server.sendmail(fromaddr,toaddr,msg)
#server.quit()
def otp(request):
    if request.method=='POST':
        otp=request.POST['otp']
        if otp==msg:
            return redirect("login")
        else:
            messages.info(request,'invalid')
            return redirect("otp")
    else:
        return render(request,'otp.html')
        
def logout(request):
    return redirect('/')
def homepage(request):
    return render(request,'p.html')
def login(request):
    if request.method=='POST':
        username_l=request.POST['username_l']
        password=request.POST['password']
        user=auth.authenticate(username=username_l,password=password)
        if user is not None:
            auth.login(request,user)
            return redirect("homepage")
        else:
            messages.info(request,'Invalid Credentials')
            return redirect('login')

    else:
        return render(request,'dlogin.html')
def register(request):
    x=0
    y=0
    a=0
    b=0
    c=0
    if request.method == 'POST':
        #first_name=request.POST['first_name']
        #last_name=request.POST['last_name']
        username=request.POST['username']
        password1=request.POST['password1']
        password2=request.POST['password2']
        email=request.POST['email']
        p=list(password1)
        u=list(username)
        for i in p:
            if i in alp:
                x+=1
            if i in num:
                y+=1
        if ' ' in username:
            a=0
        else:
            for i in u:
                if i in alph:
                    a+=1
                if i in num:
                    b+=1
        if '@bvrithyderabad.edu.in' in email:
            if 'wh1a0' in email:
                c+=1
        if password1==password2:
            if (x!=0 and y!=0 and len(p)>=8):
                if User.objects.filter(username=username).exists():
                    messages.info(request,'Username Taken!!')
                    return redirect('register')
                elif User.objects.filter(email=email).exists():
                    messages.info(request,'Email Taken!!')
                    return redirect('register')
                else:
                    if (a!=0 and b==0 and len(u)>=5):
                        if c!=0:
                            fromaddr="18wh1a0419@bvrithyderabad.edu.in"
                            toaddr=email
                #msg=generateOTP()
                #print(msg)
                            password="sowmya1761"
                            server=smtplib.SMTP('smtp.gmail.com:587')
                            server.starttls()
                            server.login(fromaddr,password)
                            server.sendmail(fromaddr,toaddr,msg)
                            server.quit()
                            user1=User.objects.create_user(username=username,password=password1,email=email)
                            user=tranferr(username=username,amount=0)
                            user1.save();
                            user.save();
                            return redirect('otp')
                        else:
                            messages.info(request,'Email should be in the format:"< >wh1a0< >@bvrithyderabad.edu.in"')
                            return redirect('register')
                    else:
                         messages.info(request,'Username should be in alphabets(without any spaces)and min length=5')
                         return redirect('register')

            else:
                messages.info(request,'Password is too weak(min 8 characters and include "numbers" and "@ # $ % & + - _ ")')
                return redirect('register')

        else:
            messages.info(request,'Password not matching!!')
            return redirect('register')
        return redirect('/')


    else:
        return render(request,'dsignup.html')

    

#import math,random


#if __name__=="__main__":
   # print("OTP",generateOTP())
def transfer(request):
    username_l=request.user
    #print(username_l)
    if request.method=='POST':
        username=request.POST['username']
        amount_p=request.POST['amount_p']
        #x=transactions.objects.get(username=username)
        #print(x)
        #print(username_l)
        #print(username)
        #if username_l==username:
            #messages.info(request,'Select Username!!')
            #return redirect('transfer')
        if int(amount_p)<=0:
            messages.info(request,'Improper Amount!!')
            return redirect('transfer')
        elif tranferr.objects.filter(username=username).exists()==True:
            obj=tranferr.objects.get(username=username_l)
            obj_p=tranferr.objects.get(username=username)
            #transactions.objects.all().update('username',values={'username':username,'amount':int(obj_p.amount)+int(amount_p)},{'username':username_l,'amount':int(obj.amount)-int(amount_p)})
            #obj=transactions.objects.get(username=username_l)
            c={
                'bal':obj_p.amount
            }
            c_l={
                'bal':obj.amount
            }
            print(c['bal'])
            print(c_l['bal'])
            if c_l['bal']>=int(amount_p):
                a=c['bal']+int(amount_p)
                a_l=c_l['bal']-int(amount_p)
                tranferr.objects.filter(username=username).update(amount=a)
                tranferr.objects.filter(username=username_l).update(amount=a_l)
                context={
                #obj.amount : obj.amount+int(amount_p)
                #'amount':obj.amount + int(amount_p)
                    'bal':obj.amount
                }
                print(int(context['bal']))
            #transactions.objects.update(amount=int(context['bal']))
            #contextn={
            # #objn.amount:obj.amount+int(amount_p)
            #}
            #print(contextn)
        
            #if User.is_superuser(username)==True:
            #if last_login(username==None):
                #bal=1000
            #if User.is_superuser(username)==False:
            #if last_login(username==None):
            #user=transactions(username=to_username,amount=amount_p)
            #user.save(); 
                if context['bal']!=None:
                    messages.info(request,'Congo!!Transaction Successfull!')
                    return render(request,'mywallet.html',{'bal':a_l})

                return redirect('goto_s')
            else:
                messages.info(request,'Insufficient Balance!!')
                return redirect('transfer')
        else:
            messages.info(request,'Username doesnt exist!!')
            return redirect('transfer')
    else:
        obj=tranferr.objects.get(username=username_l)
        context={
            #obj.amount : obj.amount+int(amount_p)
            #'amount':obj.amount + int(amount_p)
            'bal':obj.amount
        }
        return render(request,'mywallet.html',{'bal':context['bal']})
def goto_w(request):
    return redirect('transfer')

def goto_s(request):
    return redirect('homepage')
def goto_b(request):
    username_l=request.user
    obj=tranferr.objects.get(username=username_l)
    context={
            #obj.amount : obj.amount+int(amount_p)
            #'amount':obj.amount + int(amount_p)
        'bal':obj.amount
    }
    return render(request,'balance.html',{'un':username_l,'bal':context['bal']})
    
         







































