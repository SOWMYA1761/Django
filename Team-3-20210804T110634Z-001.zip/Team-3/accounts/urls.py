from django.urls import path
from . import views
urlpatterns=[
    path("register",views.register,name="register"),
    path("login",views.login,name="login"),
    path("homepage",views.homepage,name="homepage"),
    path("logout",views.logout,name="logout"),
    path("otp",views.otp,name="otp"),
    path("transfer",views.transfer,name="transfer"),
    path("goto_w",views.goto_w,name="goto_w"),
    path("goto_s",views.goto_s,name="goto_s"),
    path("goto_b",views.goto_b,name="goto_b"),

]
